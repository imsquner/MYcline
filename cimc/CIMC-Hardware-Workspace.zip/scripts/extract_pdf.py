"""
临时PDF文本提取脚本
"""
import os, sys
from pdfminer.high_level import extract_text

# 从MYcline根目录执行
source = "cimc_pdfs/GD30AD3344_Datasheet_Rev1.1.pdf"
output = "cimc_pdfs/GD30AD3344_DS.txt"

print(f"提取: {source}")
text = extract_text(source)
with open(output, "w", encoding="utf-8") as f:
    f.write(text)
print(f"完成! 共 {len(text)} 字符, 保存到 {output}")
print("---前500字---")
print(text[:500])
